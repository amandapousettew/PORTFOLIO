const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;

/* ---------- typing tagline hero ---------- */
const typeEl = document.getElementById('typeLine');
const phrases = [
  'The work. Right now.',
  'New tools. Same eye.',
  'Brand campaigns · film · set design',
  'IKEA · Adidas · and what comes next'
];
let pi = 0, ch = 0, deleting = false;
function typeLoop(){
  if(reduced){ typeEl.textContent = phrases[0]; return; }
  const word = phrases[pi];
  typeEl.innerHTML = word.slice(0, ch) + '<span class="caret"></span>';
  if(!deleting){
    ch++;
    if(ch > word.length){ deleting = true; setTimeout(typeLoop, 1600); return; }
  } else {
    ch--;
    if(ch === 0){ deleting = false; pi = (pi+1) % phrases.length; }
  }
  setTimeout(typeLoop, deleting ? 28 : 60);
}
typeLoop();

/* ---------- soft gradient canvases (bildplatshållare) ---------- */
function soft(cv){
  const ctx = cv.getContext('2d');
  const w = cv.width = cv.offsetWidth * devicePixelRatio || 600;
  const h = cv.height = cv.offsetHeight * devicePixelRatio || 800;
  const hue = +cv.dataset.h;
  const g = ctx.createLinearGradient(0,0,w,h);
  g.addColorStop(0, `hsl(${hue} 42% 78%)`);
  g.addColorStop(.55, `hsl(${hue+40} 38% 60%)`);
  g.addColorStop(1, `hsl(${hue+80} 30% 38%)`);
  ctx.fillStyle = g; ctx.fillRect(0,0,w,h);
  for(let i=0;i<3;i++){
    const rg = ctx.createRadialGradient(
      Math.random()*w, Math.random()*h, 0,
      Math.random()*w, Math.random()*h, w*.7);
    rg.addColorStop(0, `hsla(${hue+120} 60% 85% / .5)`);
    rg.addColorStop(1, 'transparent');
    ctx.fillStyle = rg; ctx.fillRect(0,0,w,h);
  }
}
function paintAll(){document.querySelectorAll('canvas.soft').forEach(soft)}
paintAll();
addEventListener('resize', paintAll);

/* ---------- animated reel canvas (videoplatshållare) ---------- */
const reel = document.getElementById('reelCanvas');
if(reel){
  const ctx = reel.getContext('2d');
  let t = 0;
  function frame(){
    const w = reel.width = reel.offsetWidth * devicePixelRatio;
    const h = reel.height = reel.offsetHeight * devicePixelRatio;
    ctx.fillStyle = '#0d0f0d'; ctx.fillRect(0,0,w,h);
    for(let i=0;i<60;i++){
      const x = w/2 + Math.cos(t*.008 + i*.35)*(w*.32)*Math.sin(i*.13+t*.004);
      const y = h/2 + Math.sin(t*.011 + i*.3)*(h*.34);
      const r = 2 + Math.abs(Math.sin(i+t*.02))*5;
      ctx.beginPath();
      ctx.fillStyle = i%9===0 ? '#7ddf9f' : `hsla(${140+i} 30% 78% / .45)`;
      ctx.arc(x, y, r*devicePixelRatio, 0, 7);
      ctx.fill();
    }
    t++;
    if(!reduced) requestAnimationFrame(frame);
  }
  frame();
}

/* ---------- soft parallax ---------- */
const strip = document.getElementById('stripTrack');
const speedEls = document.querySelectorAll('[data-speed]');
function raf(){
  if(!reduced){
    if(strip){
      strip.style.transform = `translate3d(${-(scrollY - (strip.parentElement.offsetTop - innerHeight)) * .18}px,0,0)`;
    }
    speedEls.forEach(el=>{
      const r = el.getBoundingClientRect();
      const off = (r.top + r.height/2 - innerHeight/2) * +el.dataset.speed;
      el.style.transform = `translate3d(0, ${off}px, 0)`;
    });
  }
  requestAnimationFrame(raf);
}
raf();

/* ---------- reveal ---------- */
const io = new IntersectionObserver(es=>{
  es.forEach(e=>e.isIntersecting && e.target.classList.add('in'));
},{threshold:.12});
document.querySelectorAll('.reveal').forEach(el=>io.observe(el));
