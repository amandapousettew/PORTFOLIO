# Amanda Pousette — Portfolio

## Struktur
```
vada-portfolio/
├── index.html          all markup
├── css/
│   └── style.css       all styling
├── js/
│   └── main.js         all interaktivitet (typing, parallax, canvas)
└── assets/
    ├── img/            lägg dina bilder här
    └── video/          lägg dina videor här
```

## Öppna i VS Code
1. Öppna mappen `vada-portfolio` som workspace (File > Open Folder).
2. Installera tillägget **Live Server**.
3. Högerklicka `index.html` > **Open with Live Server**.

## Byt ut platshållarna (viktigt)
Sidan visar just nu animerade gradienter, inte riktig media. Sök på `SWAP` i `index.html`. Det finns tre ställen:

**Bildremsan** och **projektkorten**
```html
<!-- före -->
<canvas class="soft" data-h="200"></canvas>
<!-- efter -->
<img src="assets/img/projekt-01.jpg" alt="Beskrivning">
```

**Motion-sektionen (video)**
```html
<!-- före -->
<canvas id="reelCanvas"></canvas>
<!-- efter -->
<video src="assets/video/reel.mp4" autoplay muted loop playsinline></video>
```

När du bytt ut ett `<canvas>` mot `<img>` eller `<video>` behöver du inget mer, canvas-koden i main.js hoppar bara över det som inte finns.

## Kvar att göra
- Byt ut de påhittade projekten (NORD, ARKIV, YTA) och loggposterna mot riktiga.
- Uppdatera mejl och sociala länkar i sidfoten.
- Byt hero-texten och koddisplayen om du vill ha något annat än studioröst.
